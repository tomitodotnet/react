//import './App.css';
//import { useReducer, useState } from 'react';

function App2() {
  return (
    <>

        <div style={{ flex: 1, flexDirection: 'row' }}>
            <h1>Car Shop</h1>
            <p>    Datos              </p>
        </div>
    </>
  );
  
}

export default App2;
