import logo from './mustang.svg';
import './App.css';

function Cabeza() {
  return (
    <div className="App">
      <header className="App-header2">
        <img src={logo} className="App-logo2" alt="logo" />
        <p>
          Car Shop Tomito
        </p>
      </header>
    </div>

  );
}

export default Cabeza;
